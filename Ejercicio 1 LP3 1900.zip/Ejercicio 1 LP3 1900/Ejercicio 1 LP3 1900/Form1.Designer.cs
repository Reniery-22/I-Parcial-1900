﻿namespace Ejercicio_1_LP3_1900
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtingreso = new System.Windows.Forms.TextBox();
            this.buttonIngreso = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtsalida = new System.Windows.Forms.TextBox();
            this.buttonSalida = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(84, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(370, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Determinar si un Numero es Par o Impar, Positivio o Negativo";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(87, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Ingrese un Numero";
            // 
            // txtingreso
            // 
            this.txtingreso.Location = new System.Drawing.Point(233, 90);
            this.txtingreso.Name = "txtingreso";
            this.txtingreso.Size = new System.Drawing.Size(110, 22);
            this.txtingreso.TabIndex = 2;
            // 
            // buttonIngreso
            // 
            this.buttonIngreso.Location = new System.Drawing.Point(233, 143);
            this.buttonIngreso.Name = "buttonIngreso";
            this.buttonIngreso.Size = new System.Drawing.Size(110, 39);
            this.buttonIngreso.TabIndex = 3;
            this.buttonIngreso.Text = "Calcular";
            this.buttonIngreso.UseVisualStyleBackColor = true;
            this.buttonIngreso.Click += new System.EventHandler(this.buttonIngreso_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(134, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 16);
            this.label6.TabIndex = 4;
            this.label6.Text = "Respuesta";
            // 
            // txtsalida
            // 
            this.txtsalida.Location = new System.Drawing.Point(233, 203);
            this.txtsalida.Name = "txtsalida";
            this.txtsalida.Size = new System.Drawing.Size(110, 22);
            this.txtsalida.TabIndex = 5;
            // 
            // buttonSalida
            // 
            this.buttonSalida.Location = new System.Drawing.Point(233, 244);
            this.buttonSalida.Name = "buttonSalida";
            this.buttonSalida.Size = new System.Drawing.Size(110, 38);
            this.buttonSalida.TabIndex = 6;
            this.buttonSalida.Text = "Vaciar";
            this.buttonSalida.UseVisualStyleBackColor = true;
            this.buttonSalida.Click += new System.EventHandler(this.buttonSalida_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(671, 322);
            this.Controls.Add(this.buttonSalida);
            this.Controls.Add(this.txtsalida);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonIngreso);
            this.Controls.Add(this.txtingreso);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textIngreso;
        private System.Windows.Forms.TextBox textSalida;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button CalcularButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtingreso;
        private System.Windows.Forms.Button buttonIngreso;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtsalida;
        private System.Windows.Forms.Button buttonSalida;
    }
}

