﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_1_LP3_1900
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonIngreso_Click(object sender, EventArgs e)
        {
            int numero;
            numero = int.Parse(txtingreso.Text);

            if (numero % 2 == 0)
            {
                txtsalida.Text = "el número: " + numero + "  es un número Par y es Positivo";
            }
            else if (numero % 2 == 0 & numero <= 0)
            {

                txtsalida.Text = "el número: " + numero + "  es un número Par y es Negativo";
            }
            else if (numero % 2 != 0 & numero >= 0)
            {
                txtsalida.Text = "el número: " + numero + "  es un número Impar pero Positivo";
            }
            else
                txtsalida.Text = "el número: " + numero + "  es un número Impar y Negativo";


        }

        private void buttonSalida_Click(object sender, EventArgs e)
        {
            txtsalida.Clear();
            txtingreso.Clear();
        }
    }
}
